# Um Veitingastaðinn

Við erum búin að elda mat fyrir fólk síðan 2001.

## Sagan

Við byrjuðum að elda árið 2001 og nam fringilla tellus a nisl scelerisque, ut varius nibh blandit. Donec dignissim vehicula justo in aliquet. In rhoncus congue ipsum ut volutpat. Morbi vehicula leo vitae odio viverra, malesuada euismod libero porttitor. Donec metus purus, luctus nec tortor sed, accumsan fermentum libero. Morbi vel lacus vel nisi molestie sollicitudin eget sed massa. Curabitur id faucibus nunc, ut blandit justo. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras ac purus ac elit vehicula pulvinar. Sed vel nunc nulla.

## Starfsfólk

### Anna Jónsdóttir

![](../myndir/anna.jpg)

Eigandi.

### Adam Adamsson

![](../myndir/adam.jpg)

Rekstrarstjóri

### Benni

![](../myndir/benni.jpg)

Kokkur

### Birna

![](../myndir/birna.jpg)

Kokkur