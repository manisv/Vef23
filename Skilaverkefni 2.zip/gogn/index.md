# Veitingastaðurinn

Á Veitingastaðnum hugsum við vel um þig og gefum þér gott að borða.

## Veitingastaðurinn

### Opnunartími

Mánudaga til fimmtudaga
  09:00–18:00
Föstudaga
  10:00–22:00
Laugardaga
  11:00–22:00
Sunnudaga
  Lokað

### Um okkur

Við erum hresst fólk sem útbýr mat alla daga nema sunnudaga.

[Lesa meira um okkur](um.html)

### Matseðill

Skoðaðu matseðilinn okkar!

[Skoða matseðilinn](matsedill.html)

### Panta

Pantaðu borð eða mat heim til þín!

[Senda inn pöntun](pontun.html)

## Vinsælir réttir

[Listi af þrem fjórum réttum af matseðli]
