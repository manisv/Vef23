# Pantanir

Pantaðu borð og mættu til okkar eða pantaðu mat sem við sendum þér eða þú sækir.

## Form (ekki hafa sér sem titil á síðu)

### Panta borð

* Hvenær viltu koma? [val um dagstíma]
* Hve mörg? [val um 1–10]
* Viltu taka eitthvað fram? [val um að skrifa inn texta]

### Panta mat

* Réttur #N [fimm reitir sem leyfa val úr titlum rétta á matseðli]
* Heimilisfang [val um að skrifa inn heimilisfang]

### Þínar upplýsingar

* Nafn [krafa um að setja inn nafn]
* Netfang [krafa um að setja inn netfang, dæmi í reit áður en skrifað]
* Sími [krafa um að setja inn síma, dæmi í reit áður en skrifað]

### Samþykkja og panta

* Ég samþykki skilmála Veitingastaðsins [box sem hægt er að haka í]
* Panta [panti til að senda pöntun]