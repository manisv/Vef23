# Fótur (ekki hafa sér sem titil á síðu)

## Opnunartími

Mánudaga til fimmtudaga
  09:00–18:00
Föstudaga
  10:00–22:00
Laugardaga
  11:00–22:00
Sunnudaga
  Lokað

## Hér erum við

Veitingastaðurinn ehf.
Aðalgata 10
100 Reykjavík
Sími 333-4567
veitingastadur@example.org
